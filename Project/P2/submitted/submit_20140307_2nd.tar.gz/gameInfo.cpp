#include "gameInfo.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include "config.h"

using namespace std;

GameInfo::GameInfo(){
	counter = 0;
}

int GameInfo::getQuiverCap() const {return quiverCap;}

int GameInfo::getRandomSeed() const {return randomSeed;}

int GameInfo::getMaxDistance() const {return maxDistance;}

int GameInfo::getMaxSpeed() const {return maxSpeed;}

int GameInfo::getMaxHealth() const {return maxHealth;}

int GameInfo::getPlayerHealth() const {return playerHealth;}

void GameInfo::setGameInfo(ifstream& file){
	string temp;
string debugcheck;
	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 17);
if(debugcheck == "Quiver_Capacity: "){
	temp.assign(temp.begin() + 17, temp.end());
	quiverCap = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}

//cout<<"debug info 0: quiverCap = " << quiverCap << endl;

	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 13);
if(debugcheck == "Random_Seed: "){
	temp.assign(temp.begin() + 13, temp.end());
	randomSeed = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}

//cout<<"debug info 1: randomSeed = " << randomSeed << endl;

	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 19);
if(debugcheck == "Max_Rand_Distance: "){
 	temp.assign(temp.begin() + 19, temp.end());
	maxDistance = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}
//cout<<"debug info 2: maxDistance = " << maxDistance << endl;

	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 16);
if(debugcheck == "Max_Rand_Speed: "){
	temp.assign(temp.begin() + 16, temp.end());
	maxSpeed = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}

//cout<<"debug info 3: maxSpeed = " << maxSpeed << endl;

	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 17);
if(debugcheck == "Max_Rand_Health: "){
	temp.assign(temp.begin() + 17, temp.end());
	maxHealth = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}

//cout<<"debug info 4: maxHealth = " << maxHealth << endl;

	getline(file, temp);
debugcheck.assign(temp.begin(), temp.begin() + 15);
if(debugcheck == "Player_Health: "){
	temp.assign(temp.begin() + 15, temp.end());
	playerHealth = atoi(temp.c_str());
}
else{
cout<<debugcheck;
}

//cout<<"debug info 5: playerHealth = " << playerHealth << endl;
}//setGameInfo

int GameInfo::getCounter(){return counter++;}

int GameInfo::getDeathtouch() const {return deathtouch;}

void GameInfo::setDeathtouch(const Config& config){
	if(config.getArrow() == "LIGHT")
		deathtouch = 1;
	else
		deathtouch = 0;
}

void GameInfo::playerBiten(int zombieHealth){
	playerHealth = (1 - deathtouch) * (playerHealth - zombieHealth);
}
