#include "zombie.h"

template<typename TYPE>
struct compList{
	bool operator()(const TYPE& a, const TYPE& b) const {
		if ((*a)->getETA() < (*b)->getETA())
			return 1;
		else {
			if ((*a)->getETA() == (*b)->getETA())
				return (*a)->getName() < (*b)->getName();
			else 
				return 0;
		}//else
	}//bool operator()
};
