#include "terrainInfo.h"
#include <sstream>
#include "out.h"
#include <deque>
#include <vector>
#include "terrainInfo.h"

using namespace std;

void mapOutput(stringstream& ss, vector<TerrainInfo>& ter, int buck,
 int farmSize, int farmNum){
	deque<int> backPath;
	backPath.push_back(buck);
	while(ter[backPath.back()].c != 'S'){
		switch (ter[backPath.back()].parent){
			case 'u': 
				backPath.push_back(backPath.back()
 + farmSize*farmSize);
				break;
			case 'd':
				backPath.push_back(backPath.back()
 - farmSize*farmSize);
				break;
			case 'e':
				backPath.push_back(backPath.back() + 1);
				break;
			case 's':
				backPath.push_back(backPath.back() + farmSize);
				break;
			case 'w':
				backPath.push_back(backPath.back() - 1);
				break;
			case 'n':
				backPath.push_back(backPath.back() - farmSize);
				break;
			default: break;
		}
	}
	int a;
	a = backPath.back();
	while(a != buck){
		backPath.pop_back();
		switch (ter[backPath.back()].parent){
			case 'u':
				ter[a].c = 'd';
				break;
			case 'd':
				ter[a].c = 'u';
				break;
			case 'e':
				ter[a].c = 'w';
				break;
			case 's':
				ter[a].c = 'n';
				break;
			case 'w':
				ter[a].c = 'e';
				break;
			case 'n':
				ter[a].c = 's';
				break;
			default: break;
		}
		a = backPath.back();
 	}
	ss << farmSize << '\n' << farmNum << '\n';
	int k, i, j;
	for(k = 0; k < farmNum; k++){
		ss << '/' << '/' << "farm " << k << '\n';
		for(i = 0; i < farmSize; i++){
			for(j = 0; j < farmSize; j++){
				ss << ter[k*farmSize*farmSize + i*farmSize + j].c;
			}
			ss << '\n';
		}
	}
}

void listOutput(stringstream& ss, vector<TerrainInfo>& ter, int buck,
 int farmSize, int farmNum){
	ss << farmSize << '\n' << farmNum << '\n'
 << "//path taken \n";
	deque<int> backPath;
	backPath.push_back(buck);
	while(ter[backPath.back()].c != 'S'){
		switch (ter[backPath.back()].parent){
			case 'u': 
				backPath.push_back(backPath.back()
 + farmSize*farmSize);
				break;
			case 'd':
				backPath.push_back(backPath.back()
 - farmSize*farmSize);
				break;
			case 'e':
				backPath.push_back(backPath.back() + 1);
				break;
			case 's':
				backPath.push_back(backPath.back() + farmSize);
				break;
			case 'w':
				backPath.push_back(backPath.back() - 1);
				break;
			case 'n':
				backPath.push_back(backPath.back() - farmSize);
				break;
			default: break;
		}
	}
	int a;
	a = backPath.back(); 
	while(a != buck){
		backPath.pop_back();
		switch (ter[backPath.back()].parent){
			case 'u':
				ter[a].c = 'd';
				break;
			case 'd':
				ter[a].c = 'u';
				break;
			case 'e':
				ter[a].c = 'w';
				break;
			case 's':
				ter[a].c = 'n';
				break;
			case 'w':
				ter[a].c = 'e';
				break;
			case 'n':
				ter[a].c = 's';
				break;
			default: break;
		}
		ss << '(' << ter[a].x << ',' << ter[a].y << ','
 << ter[a].l << ',' << ter[a].c << ')' << '\n';
		a = backPath.back();
 	}
	ss << '(' << ter[buck].x << ',' << ter[buck].y << ','
 << ter[buck].l << ',' << ter[buck].c << ')' << '\n';
}
