#ifndef GUARD_readin_h
#define GUARD_readin_h

#include <iostream>
#include <vector>

struct TerrainInfo{
	int x, y, l; 
	// (x,y) are the coordinates for every terrain,
	// l is the level of the farm
	char c; 
	// c is used to record the character of the terrain
	TerrainInfo* parent;
	bool store;
};

int listRead(std::istream&, std::vector<TerrainInfo>&, int, int);

int mapRead(std::istream&, std::vector<TerrainInfo>&, int);

#endif
