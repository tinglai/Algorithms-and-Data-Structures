#include <vector>
#include <deque>
#include "route.h"

using namespace std;

int stackRoute(vector<TerrainInfo>& ter, int start, int farmSize, int farmNum){
	deque<TerrainInfo*> container;
	container.push_back(&ter[start]);
	TerrainInfo* current;
	while(1){
		if(container.empty()){
			return start;
		}
		if((*container.back()).c == 'B'){
			return container.back()->l * (farmSize*farmSize) 
+ container.back()->x * farmSize + container.back()->y; 
		}
		/*when the container is empty, there is no way to B*/
		current = container.back();
		container.pop_back();
		addNeighbor(container, ter, current, farmSize, farmNum);
	}
}

int queueRoute(vector<TerrainInfo>& ter, int start, int farmSize, int farmNum){
	deque<TerrainInfo*> container;
	container.push_back(&ter[start]);
	TerrainInfo* current;
	while(1){
		/*when the container is empty, there is no way to B*/
		if(container.empty()){
			return start;
		}
		if((*container.front()).c == 'B'){
			return container.front()->l * (farmSize*farmSize)
 + container.front()->x * farmSize + container.front()->y;
		}
		current = container.front();
		container.pop_front();
		addNeighbor(container, ter, current, farmSize, farmNum);
		}
}

void addNeighbor(deque<TerrainInfo*>& container, vector<TerrainInfo>& ter,
 TerrainInfo* current, int farmSize, int farmNum){
	TerrainInfo* next;

	/*ladder up*/
	//cout<<"debug infor in addNeighbor: "<<ter[1].c<<" "<<endl;
	if (current->c == '>'){
		/*a next terrain exists if current is not at the highest level*/
		if (current->l != farmNum - 1){
			next = &ter[(current->l+1) * (farmSize*farmSize) + current->x * farmSize + current->y];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}
	}
	/*ladder down*/
	else if (current->c == '<'){
		/*a next terrain exists if current is not at the lowest level*/
		if (current->l != 0){
			next = &ter[(current->l-1) * (farmSize*farmSize) + current->x * farmSize + current->y];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}

	}
	/*field and starting point*/
	else{
		/*north*/
		/*a next terrain exists if current is not at the top line*/
		if (current->x != 0){
			next = &ter[current->l * (farmSize*farmSize) + (current->x-1) * farmSize + current->y];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}
		/*east*/
		/*a next terrain exists if current is not at the right line*/
		if (current->y != farmSize-1){
			next = &ter[current->l * (farmSize*farmSize) + current->x * farmSize + current->y+1];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}
		/*south*/
		/*a next terrain exists if current is not at the bottom line*/
		if (current->x != farmSize-1){
			next = &ter[current->l * (farmSize*farmSize) + (current->x+1) * farmSize + current->y];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}
		/*west*/
		/*a next terrain exists if current is not at the left line*/
		if (current->y != 0){
			next = &ter[current->l * (farmSize*farmSize) + current->x * farmSize + current->y-1];
			/*check if the next terrain is walkable and if has ever been stored in the container*/
			if (next->c != '#' && next->store == 0){
				container.push_back(next);
				next->store = 1;
				next->parent = current;
			}
		}
	}
	//cout<<"debug infor in addNeighbor: "<<ter[1].c<<" "<<endl;
}
