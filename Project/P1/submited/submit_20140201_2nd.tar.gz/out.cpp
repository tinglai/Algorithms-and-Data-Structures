#include "terrainInfo.h"
#include <sstream>
#include "out.h"
#include <deque>
#include <vector>
#include "terrainInfo.h"

using namespace std;

void mapOutput(stringstream& ss, vector<TerrainInfo>& ter, int buck,
 int farmSize, int farmNum){
	deque<TerrainInfo*> backPath;
	backPath.push_back(&ter[buck]);
	while((*backPath.back()).c != 'S'){
		backPath.push_back((*backPath.back()).parent);
	}
	int a, b;
	a = backPath.back()->l * (farmSize*farmSize) + backPath.back()->x
 		* farmSize + backPath.back()->y; 
	while(a != buck){
		backPath.pop_back();
		b = backPath.back()->l * (farmSize*farmSize)
			 + backPath.back()->x * farmSize + backPath.back()->y;
		if (ter[a].l - ter[b].l == 1)
			ter[a].c = 'd';
		else if (ter[a].l - ter[b].l == -1)
			ter[a].c = 'u';
		else if (ter[a].x - ter[b].x == 1)
			ter[a].c = 'n';
		else if (ter[a].x - ter[b].x == -1)
			ter[a].c = 's';
		else ter[a].c = (ter[a].y - ter[b].y == 1)? 'w':'e';
		a = b;
 	}
	ss << farmSize << '\n' << farmNum << '\n';
	int k, i, j;
	for(k = 0; k < farmNum; k++){
		ss << '/' << '/' << "farm " << k << '\n';
		for(i = 0; i < farmSize; i++){
			for(j = 0; j < farmSize-1; j++){
				ss << ter[k*farmSize*farmSize + i*farmSize + j].c;
			}
			ss << ter[k*farmSize*farmSize + i*farmSize + j].c << '\n';
		}
	}
}

void listOutput(stringstream& ss, vector<TerrainInfo>& ter, int buck,
 int farmSize, int farmNum){
	ss << farmSize << '\n' << farmNum << '\n'
 << "//path taken \n";

	deque<TerrainInfo*> backPath;
	backPath.push_back(&ter[buck]);
	while((*backPath.back()).c != 'S'){
		backPath.push_back((*backPath.back()).parent);
	}
	int a, b;
	a = backPath.back()->l * (farmSize*farmSize) + backPath.back()->x
		 * farmSize + backPath.back()->y; 
	while(a != buck){
		backPath.pop_back();
		b = backPath.back()->l * (farmSize*farmSize)
			 + backPath.back()->x * farmSize + backPath.back()->y;
		if (ter[a].l - ter[b].l == 1)
			ter[a].c = 'd';
		else if (ter[a].l - ter[b].l == -1)
			ter[a].c = 'u'; 
		else if (ter[a].x - ter[b].x == 1)
			ter[a].c = 'n'; 
		else if (ter[a].x - ter[b].x == -1)
			ter[a].c = 's'; 
		else ter[a].c = (ter[a].y - ter[b].y == 1)? 'w':'e';
		ss << '(' << ter[a].x << ',' << ter[a].y << ','
 << ter[a].l << ',' << ter[a].c << ')' << '\n';
		a = b;
 	}
	ss << '(' << ter[buck].x << ',' << ter[buck].y << ','
 << ter[buck].l << ',' << ter[buck].c << ')' << '\n';
}

